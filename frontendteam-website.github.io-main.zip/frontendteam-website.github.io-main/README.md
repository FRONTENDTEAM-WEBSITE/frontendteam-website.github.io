# frontendteam-website.github.io
Este repositório será utilizado para o desenvolvimento de um site feito em HTML, CSS e Bootstrap, criado em conjunto com minha equipe da faculdade. O projeto está em andamento e tem como objetivo aplicar conhecimentos de desenvolvimento web responsivo e design moderno. Conforme avançarmos, o código e os recursos serão atualizados aqui.

Figma: https://www.figma.com/team_invite/redeem/6xz5lPgSLgg3ywi92oj2dc
